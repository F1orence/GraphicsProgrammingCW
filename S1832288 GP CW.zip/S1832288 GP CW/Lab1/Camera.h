#pragma once

#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>

struct Camera
{
public:
	Camera()
	{
	}

	void initCamera(const glm::vec3& pos, float fov, float aspect, float nearClip, float farClip)
	{
		this->pos = pos;
		this->forward = glm::vec3(0.0f, 0.0f, 1.0f);
		this->up = glm::vec3(0.0f, 1.0f, 0.0f);
		this->projection = glm::perspective(fov, aspect, nearClip, farClip);
	}

	void SetPos(glm::vec3 pos)
	{
		this->pos = pos;
	}

	void panLeft()
	{
		forward.x += 0.01f;
	}

	void panRight()
	{

		forward.x -= 0.01f;
	}

	glm::vec3 getPos()
	{
		return this->pos;
	}

	glm::mat4 GetViewM()
	{
		return glm::lookAt(pos, pos + forward, up);
	}

	glm::mat4 GetProjM()
	{
		return projection;
	}

	inline glm::mat4 GetViewProjection() const
	{
		return projection * glm::lookAt(pos, pos + forward, up);
	}



protected:
private:
	glm::mat4 projection;
	glm::vec3 pos;
	glm::vec3 forward;
	glm::vec3 up;
};


