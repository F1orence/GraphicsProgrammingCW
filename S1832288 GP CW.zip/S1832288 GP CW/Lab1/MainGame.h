#pragma once
#include <SDL\SDL.h>
#include <GL/glew.h>
#include "Display.h" 
#include "Shader.h"
#include "Mesh.h"
#include "Texture.h"
#include "transform.h"

enum class GameState{PLAY, EXIT};

class MainGame
{
public:
	MainGame();
	~MainGame();

	void run();

private:

	void initSystems();
	void processInput();
	void gameLoop();
	void drawGame();

	void drawSkyBox();
	void timeSwitch();

	void updateSkybox(float x, float y, float z);

	Display _gameDisplay;
	GameState _gameState;


	Mesh monkeyMesh;
	Mesh manMesh;
	Mesh sphereMesh;
	Mesh windowMesh;
	Mesh wallMesh;
	Mesh lightMesh;
	Mesh textMesh;

	Texture texture;
	Texture texture1;
	Texture windowTex;
	Texture skyboxTexture;
	Texture reflectionTexture;
	Texture manTexture;

	Shader geoExplodeShader;
	Shader reflectionShader;
	Shader adsShader;
	Shader skyboxShader;
	Shader normalMapShader;
	Shader colourShader;
	Shader diffuseColourShader;

	glm::vec3 worldColour;

	GLuint skyboxVAO, skyboxVBO, cubemapTexture, reflectionCubemapTexture;

	Camera myCamera;

	float counter, s2Counter;
	bool daytime;
	int stageState, stageCounter;
};

