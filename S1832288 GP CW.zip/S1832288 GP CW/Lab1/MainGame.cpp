#include "MainGame.h"
#include "Camera.h"
#include <iostream>
#include <string>
#include <conio.h>
#include "Windows.h"


Transform transform;

MainGame::MainGame()
{
	_gameState = GameState::PLAY;
	Display* _gameDisplay = new Display(); //new display
    Mesh* mesh1();
	Mesh* mesh2();
	Mesh* mesh3();

	Texture* texture(); 
	Texture* texture1(); 

	Shader* shaderPass();
	Shader* shaderBlur();

	Shader* reflectionShader();
	Shader* adsShader();
	Shader* normalMapShader();
	Shader* colourShader();
}

MainGame::~MainGame() 
{
}

void MainGame::run()
{
	initSystems(); 
	gameLoop();
}

void MainGame::initSystems()
{
	daytime = true;
	stageState = 0; // 0 = look at normal window, 1 = turn towards ADS sphere, 2 = look at sphere and change time, 3 = turn back to the window and to the MC models, 4 = look at models, 5 = return to window
	stageCounter = 0;

	_gameDisplay.initDisplay(); 

	#pragma region initialize textures
	texture.init("..\\res\\bricks.jpg");
	texture1.init("..\\res\\water.jpg"); 
	windowTex.init("..\\res\\windowNormalTexture.png");
	manTexture.init("..\\res\\manTexture1.png");
#pragma endregion

	#pragma region initialize shaders

	geoExplodeShader.init("..\\res\\shaderGeoText.vert", "..\\Lab1\\explodingGeoShader.geom", "..\\res\\shaderGeoText.frag");
	adsShader.init("..\\Lab1\\ADS.vert", "..\\Lab1\\passThrough.geom", "..\\Lab1\\ADS.frag");
	reflectionShader.init("..\\Lab1\\ADS.vert", "..\\Lab1\\passThrough.geom", "..\\Lab1\\shaderReflection.frag");
	normalMapShader.init("..\\Lab1\\shaderNormalMap.vert","..\\Lab1\\shaderNormalMap.frag");
	colourShader.init("..\\Lab1\\basicVertexShader.vert", "..\\Lab1\\blockColourFragmentShader.frag");
	diffuseColourShader.init("..\\Lab1\\shaderNormalMap.vert", "..\\Lab1\\shaderColourDiffuse.frag");
#pragma endregion

	#pragma region intialize meshes
	monkeyMesh.loadModel("..\\res\\monkey3.obj");
	manMesh.loadModel("..\\res\\man.obj");
	sphereMesh.loadModel("..\\res\\sphereOpen.obj");
	windowMesh.loadModel("..\\res\\plane.obj");
	wallMesh.loadModel("..\\res\\wall.obj");
	lightMesh.loadModel("..\\res\\appleModel.obj");
	textMesh.loadModel("..\\res\\enemyModel.obj");
#pragma endregion
	
	myCamera.initCamera(glm::vec3(0, 0, -3), 70.0f, (float)_gameDisplay.getWidth()/_gameDisplay.getHeight(), 0.01f, 1000.0f);

	#pragma region initialize sky box
	skyboxShader.init("..\\res\\shaderSkybox.vert", "..\\res\\shaderSkybox.frag");

	vector<std::string> faces
	{
		"..\\res\\skybox\\blanc.jpg",
		"..\\res\\skybox\\blanc.jpg",
		"..\\res\\skybox\\blanc.jpg",
		"..\\res\\skybox\\blanc.jpg",
		"..\\res\\skybox\\bw_mountain.png",
		"..\\res\\skybox\\blanc.jpg"
	};

	cubemapTexture = skyboxTexture.loadCubemap(faces); //Load the cubemap using "faces" into cubemapTextures


	skyboxShader.Bind();
	skyboxShader.setMat4("view", myCamera.GetViewM());
	skyboxShader.setMat4("projection", myCamera.GetProjM());
	skyboxShader.setVec3("inColourD", glm::vec3(1, 1, 1));
	skyboxShader.setVec3("inColourS", glm::vec3(0.1, 1, 1));
	skyboxShader.setVec3("inColourM", glm::vec3(0.1, 0.4, 0.2));
	skyboxShader.setVec3("inColourC", glm::vec3(1, 1, 1));

	adsShader.Bind();
	adsShader.setVec3("lightDir", glm::vec3(-1, 0.3, -0.9));
	adsShader.setVec3("ambColour", glm::vec3(0.4, 0.71, 0.76));
	diffuseColourShader.Bind();
	diffuseColourShader.setVec3("lightDir", glm::vec3(-0.8, 0, -1));

	worldColour = glm::vec3(0.5, 0.5, 0.5);

	float skyboxVertices[] = {
		// positions          
		-1.0f,  1.0f, -1.0f,
		-1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f,  1.0f, -1.0f,
		-1.0f,  1.0f, -1.0f,

		-1.0f, -1.0f,  1.0f,
		-1.0f, -1.0f, -1.0f,
		-1.0f,  1.0f, -1.0f,
		-1.0f,  1.0f, -1.0f,
		-1.0f,  1.0f,  1.0f,
		-1.0f, -1.0f,  1.0f,

		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,

		-1.0f, -1.0f,  1.0f,
		-1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f, -1.0f,  1.0f,
		-1.0f, -1.0f,  1.0f,

		-1.0f,  1.0f, -1.0f,
		1.0f,  1.0f, -1.0f,
		1.0f,  1.0f,  1.0f,
		1.0f,  1.0f,  1.0f,
		-1.0f,  1.0f,  1.0f,
		-1.0f,  1.0f, -1.0f,

		-1.0f, -1.0f, -1.0f,
		-1.0f, -1.0f,  1.0f,
		1.0f, -1.0f, -1.0f,
		1.0f, -1.0f, -1.0f,
		-1.0f, -1.0f,  1.0f,
		1.0f, -1.0f,  1.0f
	};


	//use openGL functionality to generate & bind data into buffers
	glGenVertexArrays(1, &skyboxVAO);
	glBindVertexArray(skyboxVAO);
	glGenBuffers(1, &skyboxVBO);
	//glBindVertexArray(skyboxVAO);
	glBindBuffer(GL_ARRAY_BUFFER, skyboxVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(skyboxVertices), &skyboxVertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), (void*)0);

#pragma region reflection skybox
	faces =
	{
		"..\\res\\skybox\\bw_mountain.png",
		"..\\res\\skybox\\bw_mountain.png",
		"..\\res\\skybox\\blanc.jpg",
		"..\\res\\skybox\\fullBlack.jpg",
		"..\\res\\skybox\\bw_mountain.png",
		"..\\res\\skybox\\bw_mountain.png"
	};

	reflectionCubemapTexture = reflectionTexture.loadCubemap(faces);

	reflectionShader.Bind();
	reflectionShader.setVec3("inColourD", glm::vec3(0.1, 1, 1));
	reflectionShader.setVec3("inColourS", glm::vec3(0.1, 1, 1));
	reflectionShader.setVec3("inColourM", glm::vec3(0.1, 0.4, 0.2));
	reflectionShader.setVec3("inColourC", glm::vec3(1, 1, 1));
#pragma endregion

#pragma endregion


	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA); // enable transparency
	glEnable(GL_BLEND);
	glClearColor(0.0, 0.0, 0.0, 0.0);

	counter = 1.0f;
}

void MainGame::gameLoop()
{
	while (_gameState != GameState::EXIT)
	{
		processInput();

		switch (stageState)
		{
			case (0): // look at window
			{
				stageCounter++;

				if (stageCounter == 550) // after a duration, move stage 1
				{
					stageState = 1;
					stageCounter = 0;
				}
			}
			break;

			case (1): // turn to sphere
			{
				stageCounter++;
				myCamera.panLeft();

				if (stageCounter == 300) // after a duration, move stage 2
				{
					stageState = 2;
					stageCounter = 0;
					s2Counter = 0;
				}
			}
			break;

			case (2): // look at sphere
			{
				stageCounter++;

				if (stageCounter == 200) // after a duration, move stage 3
				{
					stageState = 3;
					stageCounter = 0;
					timeSwitch();
				}
			}
			break;

			case (3): // turn to figures
			{
				myCamera.panRight();
				stageCounter++;

				if (stageCounter == 400) // after a duration, move stage 4
				{
					stageState = 4;
					stageCounter = 0;
				}
				else if (stageCounter > 300) // change background colour once figures are in focus
				{
					worldColour = glm::vec3(sinf(counter), -sinf(counter), cosf(counter));
				}
			}
			break;

			case (4): // look at figures
			{
				worldColour = glm::vec3(sinf(counter), -sinf(counter), cosf(counter));

				stageCounter++;
				
				if (stageCounter == 400) // after a duration, move stage 5
				{
					stageState = 5;
					stageCounter = 0;
				}
			}
			break;

			case (5): // return to window
			{
				myCamera.panLeft();
				stageCounter++;

				if (stageCounter == 100) // after a duration, return to stage 0
				{
					stageState = 0;
					stageCounter = 0;
				}
				else if (stageCounter < 90) // change background colour while figures are still in focus 
				{
					worldColour = glm::vec3(sinf(counter), -sinf(counter), cosf(counter));
				}
				else
				{
					if (daytime) // reset background colour based on 'time of day'
					{
						worldColour = glm::vec3(0.5, 0.5, 0.5);
					}
					else
					{
						worldColour = glm::vec3(0.2, 0, 0);
					}
				}
			}
			break;
		}

		drawGame();
	}
}

void MainGame::processInput()
{
	SDL_Event evnt;

	while(SDL_PollEvent(&evnt))
	{
		switch (evnt.type)
		{
			case SDL_QUIT:
				_gameState = GameState::EXIT;
				break;
		}
	}
	
}

void MainGame::updateSkybox(float x, float y, float z)
{
	float skyboxVertices[] = {
         
		x - 1.0f, y + 1.0f, z - 1.0f,
		x - 1.0f, y - 1.0f, z - 1.0f,
		x + 1.0f, y - 1.0f, z - 1.0f,
		x + 1.0f, y - 1.0f, z - 1.0f,
		x + 1.0f, y + 1.0f, z - 1.0f,
		x - 1.0f, y + 1.0f, z - 1.0f,

		x- 1.0f, y - 1.0f, z + 1.0f,
		x- 1.0f, y - 1.0f, z - 1.0f,
		x- 1.0f, y + 1.0f, z - 1.0f,
		x- 1.0f, y + 1.0f, z - 1.0f,
		x- 1.0f, y + 1.0f, z + 1.0f,
		x- 1.0f, y - 1.0f, z + 1.0f,

		x + 1.0f, y - 1.0f, z - 1.0f,
		x + 1.0f, y - 1.0f, z + 1.0f,
		x + 1.0f, y + 1.0f, z + 1.0f,
		x + 1.0f, y + 1.0f, z + 1.0f,
		x + 1.0f, y + 1.0f, z - 1.0f,
		x + 1.0f, y - 1.0f, z - 1.0f,

		x - 1.0f, y - 1.0f, z + 1.0f,
		x - 1.0f, y + 1.0f, z + 1.0f,
		x + 1.0f, y + 1.0f, z + 1.0f,
		x + 1.0f, y + 1.0f, z + 1.0f,
		x + 1.0f, y - 1.0f, z + 1.0f,
		x - 1.0f, y - 1.0f, z + 1.0f,

		x - 1.0f, y + 1.0f, z - 1.0f,
		x + 1.0f, y + 1.0f, z - 1.0f,
		x + 1.0f, y + 1.0f, z + 1.0f,
		x + 1.0f, y + 1.0f, z + 1.0f,
		x - 1.0f, y + 1.0f, z + 1.0f,
		x - 1.0f, y + 1.0f, z - 1.0f,

		x - 1.0f, y - 1.0f, z - 1.0f,
		x - 1.0f, y - 1.0f, z + 1.0f,
		x + 1.0f, y - 1.0f, z - 1.0f,
		x + 1.0f, y - 1.0f, z - 1.0f,
		x - 1.0f, y - 1.0f, z + 1.0f,
		x + 1.0f, y - 1.0f, z + 1.0f
	};
	

	glBindVertexArray(skyboxVAO);
	glBindBuffer(GL_ARRAY_BUFFER, skyboxVBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(skyboxVertices), &skyboxVertices, GL_STATIC_DRAW);
	glEnableVertexAttribArray(0);
}

void MainGame::timeSwitch() // change the colours used in the skybox/reflection shader to match the 'time of day'
{
	if (daytime)
	{
		skyboxShader.Bind();

		skyboxShader.setVec3("inColourS", glm::vec3(1, 0.5, 0.1));
		skyboxShader.setVec3("inColourM", glm::vec3(0, 0, 0));
		skyboxShader.setVec3("inColourC", glm::vec3(0.3, 0.3, 0.4));

		reflectionShader.Bind();
		reflectionShader.setVec3("inColourD", glm::vec3(1, 0.5, 0.1));
		reflectionShader.setVec3("inColourS", glm::vec3(1, 0.5, 0.1));
		reflectionShader.setVec3("inColourM", glm::vec3(0, 0, 0));
		reflectionShader.setVec3("inColourC", glm::vec3(0.3, 0.3, 0.4));

		daytime = false;
	}
	else
	{
		skyboxShader.Bind();
		skyboxShader.setVec3("inColourS", glm::vec3(0.1, 1, 1));
		skyboxShader.setVec3("inColourM", glm::vec3(0.1, 0.4, 0.2));
		skyboxShader.setVec3("inColourC", glm::vec3(1, 1, 1));

		reflectionShader.Bind();
		reflectionShader.setVec3("inColourD", glm::vec3(0.1, 1, 1));
		reflectionShader.setVec3("inColourS", glm::vec3(0.1, 1, 1));
		reflectionShader.setVec3("inColourM", glm::vec3(0.1, 0.4, 0.2));
		reflectionShader.setVec3("inColourC", glm::vec3(1, 1, 1));

		daytime = true;
	}
}

void MainGame::drawSkyBox()
{
	skyboxShader.Bind();

	glDepthFunc(GL_LEQUAL);  // change depth function so depth test passes when values are equal to depth buffer's content
	skyboxShader.setInt("skybox", 0);
	glm::mat4 view = glm::mat4(glm::mat3(myCamera.GetViewM())); // remove translation from the view matrix
	skyboxShader.setMat4("view", view);
	skyboxShader.setMat4("projection", myCamera.GetProjM());
	skyboxShader.setVec3("inColourD", worldColour);

	glBindVertexArray(skyboxVAO);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_CUBE_MAP, cubemapTexture);
	glDrawArrays(GL_TRIANGLES, 0, 36);
	glBindVertexArray(0);
	glDepthFunc(GL_LESS); // set depth function back to default
}


void MainGame::drawGame()
{
	_gameDisplay.clearDisplay(0.0f, 1.0f, 0.0f, 1.0f);

	drawSkyBox();

	geoExplodeShader.Bind();
	transform.SetPos(glm::vec3(7, 0, 2.0));
	transform.SetRot(glm::vec3(0, 0.5 * counter, 0));
	transform.SetScale(glm::vec3(0.2, 0.2, 0.2));
	geoExplodeShader.setFloat("time", counter);
	geoExplodeShader.setFloat("randColourX", (0.5f * sinf(counter)) + 0.5f);
	geoExplodeShader.setFloat("randColourY", (0.5f * cosf(counter)) + 0.5f);
	geoExplodeShader.setFloat("randColourZ", (0.5f * sinf(-counter)) + 0.5f);
	geoExplodeShader.Update(transform, myCamera);
	geoExplodeShader.setMat4("u_mm", transform.GetModel());
	geoExplodeShader.setMat4("u_vm", myCamera.GetViewM());
	geoExplodeShader.setMat4("u_pm", myCamera.GetProjM());
	texture1.Bind(0);
	textMesh.draw();

	adsShader.Bind();
	transform.SetPos(glm::vec3(60, 0, 3));
	transform.SetRot(glm::vec3(0.0, 0.0, 0.0));
	transform.SetScale(glm::vec3(0.6, 0.6, 0.6));
	adsShader.Update(transform, myCamera);
	adsShader.setMat4("u_mm", transform.GetModel());
	#pragma region time dependent changes in stage 2
	if (stageState == 2)
	{
		s2Counter += 0.01f;

		if (daytime)
		{
			adsShader.setVec3("lightDir", glm::vec3(-1, 0.3, -0.9 + 0.9*s2Counter)); // change z value from -0.9 to 0.9 over the course of the stage
			adsShader.setVec3("ambColour", glm::vec3(0.4 + 0.29 * s2Counter, 0.71 - 0.115*s2Counter, 0.76 - 0.29*s2Counter)); // transition from 'day' colour to 'evening' colour over the course of the stage
			
			worldColour = glm::vec3(0.5 - 0.15*s2Counter, 0.5 - 0.25*s2Counter, 0.5 - 0.25 * s2Counter);
		}
		else
		{
			adsShader.setVec3("lightDir", glm::vec3(-1, 0.3, 0.9 - (0.9)*s2Counter)); // change z value from 0.9 to -0.9 over the course of the stage
			adsShader.setVec3("ambColour", glm::vec3(0.98 - (0.29 * s2Counter), 0.48 + (0.115 * s2Counter), 0.18 + (0.29 * s2Counter))); // transition from 'evening' colour to 'day' colour by a factor of the counter

			worldColour = glm::vec3(0.2 + 0.15 * s2Counter, 0.25 * s2Counter, 0.25 * s2Counter);
		}
	}
#pragma endregion
	texture.Bind(0);
	sphereMesh.draw();

	transform.SetPos(glm::vec3(0, 0, 40));
	transform.SetRot(glm::vec3(0, counter * 2, 0));
	transform.SetScale(glm::vec3(4, 4, 4));
	reflectionShader.Bind();
	reflectionShader.setVec3("cameraPos", myCamera.getPos());
	reflectionShader.setInt("skybox", 0);
	reflectionShader.setMat4("u_mm", transform.GetModel());
	reflectionShader.Update(transform, myCamera);
	glBindTexture(GL_TEXTURE_CUBE_MAP, reflectionCubemapTexture);
	monkeyMesh.draw();

	transform.SetRot(glm::vec3(4.69, 0, 0));
	transform.SetPos(glm::vec3(0, 0, 30.1));
	transform.SetScale(glm::vec3(0.6, 0.6, 0.6));
	colourShader.Bind();
	colourShader.Update(transform, myCamera);
	colourShader.setVec3("inColour",worldColour);
	wallMesh.draw();

	transform.SetPos(glm::vec3(6 * (sinf(counter)), 6 * cosf(counter), 20));
	colourShader.Update(transform, myCamera);
	colourShader.setVec3("inColour", glm::vec3(254,244,142));
	lightMesh.draw();

	normalMapShader.Bind();
	transform.SetRot(glm::vec3(4.69, 0, 0));
	normalMapShader.setVec3("lightDir", glm::vec3(-transform.GetPos()->x, transform.GetPos()->y, 30 - transform.GetPos()->z));
	transform.SetPos(glm::vec3(0, 0, 30)); // this is done here so that the dynamic position of the light source is still used for the above uniform
	normalMapShader.setMat4("u_mm", transform.GetModel());
	normalMapShader.Update(transform, myCamera);
	windowTex.Bind(0);
	windowMesh.draw();

	diffuseColourShader.Bind();
	transform.SetRot(glm::vec3(0, 3 + sinf(counter), 0));
	transform.SetPos(glm::vec3(-5, 0, 1.5));
	transform.SetScale(glm::vec3(0.03, 0.03, 0.03));
	diffuseColourShader.setMat4("u_mm", transform.GetModel());
	diffuseColourShader.setVec3("inColour", worldColour);
	diffuseColourShader.Update(transform, myCamera);
	manTexture.Bind(0);
	manMesh.draw();

	transform.SetRot(glm::vec3(0, 3 + sinf(counter), 0));
	transform.SetPos(glm::vec3(-5, 0, 3));
	transform.SetScale(glm::vec3(0.6, 0.6, 0.6));
	diffuseColourShader.setMat4("u_mm", transform.GetModel());
	diffuseColourShader.Update(transform, myCamera);
	texture.Bind(0);
	monkeyMesh.draw();


	counter += 0.01f;

	glEnableClientState(GL_COLOR_ARRAY); 
	glEnd();

	_gameDisplay.swapBuffer();
} 